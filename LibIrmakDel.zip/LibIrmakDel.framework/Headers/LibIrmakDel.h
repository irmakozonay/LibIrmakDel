//
//  LibIrmakDel.h
//  LibIrmakDel
//
//  Created by Irmak Ozonay on 19.03.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for LibIrmakDel.
FOUNDATION_EXPORT double LibIrmakDelVersionNumber;

//! Project version string for LibIrmakDel.
FOUNDATION_EXPORT const unsigned char LibIrmakDelVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LibIrmakDel/PublicHeader.h>


